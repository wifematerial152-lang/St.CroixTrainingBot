import http from "node:http";
import { Client, GatewayIntentBits, Partials } from "discord.js";
import { logger } from "./lib/logger";
import { handleMessage } from "./bot/messageHandler";
import { handleInteraction } from "./bot/interactionHandler";

const token = process.env["DISCORD_BOT_TOKEN"];
if (!token) {
  throw new Error("DISCORD_BOT_TOKEN environment variable is required.");
}

const rawPort = process.env["PORT"] ?? "8080";
const port = Number(rawPort);

// Minimal HTTP server so the workflow runner's port-check succeeds.
// The bot itself runs entirely over the Discord WebSocket connection.
const server = http.createServer((_req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ status: "ok", service: "discord-bot" }));
});

server.listen(port, () => {
  logger.info({ port }, "Health endpoint listening");
});

export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Channel, Partials.Message],
});

client.once("ready", () => {
  logger.info({ tag: client.user?.tag }, "Discord bot is online");
});

client.on("messageCreate", handleMessage);
client.on("interactionCreate", handleInteraction);

client.login(token).catch((err) => {
  logger.error({ err }, "Failed to log in to Discord");
  process.exit(1);
});
